<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/edituser?id=').$before->id; ?>">User Details</a></li>
<li><a href="<?php echo site_url('site/viewpublication?id=').$before->id; ?>">Publications</a></li>
<li><a href="<?php echo site_url('site/viewpatent?id=').$before->id; ?>">patents</a></li>
<li><a href="<?php echo site_url('site/viewlanguage?id=').$before->id; ?>">languages</a></li>
<li><a href="<?php echo site_url('site/viewskill?id=').$before->id; ?>">skills</a></li>
<li><a href="<?php echo site_url('site/vieweducation?id=').$before->id; ?>">educations</a></li>
<li><a href="<?php echo site_url('site/viewcourse?id=').$before->id; ?>">courses</a></li>
<li><a href="<?php echo site_url('site/viewcertification?id=').$before->id; ?>">certifications</a></li>
<li><a href="<?php echo site_url('site/viewusergallery?id=').$before->id; ?>">usergallerys</a></li>
<li><a href="<?php echo site_url('site/viewuserquestion?id=').$before->id; ?>">User Questions</a></li>
</ul>
</div>
</section>