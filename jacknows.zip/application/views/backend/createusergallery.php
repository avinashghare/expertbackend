<div id="page-title">
    <a href="<?php echo site_url("site/viewusergallery?id=".$user); ?>" class="btn btn-primary btn-labeled fa fa-arrow-left margined pull-right">Back</a>
    <h1 class="page-header text-overflow">usergallery Details </h1>
</div>
<div id="page-content">
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">
Create usergallery </h3>
                </div>
                <div class="panel-body">
                    <form class='form-horizontal tasi-form' method='post' action='<?php echo site_url("site/createusergallerysubmit");?>' enctype='multipart/form-data'>
                        <div class="panel-body">
                            <div class=" form-group" style="display:none;">
                                <label class="col-sm-2 control-label" for="normal-field">User</label>
                                <div class="col-sm-6">
                                    <input type="text" id="normal-field" class="form-control" name="user" value='<?php echo set_value(' user ',$user);?>'>
                                </div>
                            </div>
                            <div class=" form-group">
                                <label class="col-sm-2 control-label" for="normal-field">Type</label>
                                <div class="col-sm-4">
                                    <?php echo form_dropdown( "type",$type,set_value( 'type'), "id='select88' class='chzn-select form-control'  onchange='changetype()'");?>
                                </div>
                            </div>
                            <div class=" form-group imageclass" style="display:none;">
                                <label class="col-sm-2 control-label" for="normal-field">Image</label>
                                <div class="col-sm-4">
                                    <input type="file" id="normal-field" class="form-control" name="image" value='<?php echo set_value(' image ');?>'>
                                </div>
                            </div>
                            <div class=" form-group audioclass" style="display:none;">
                                <label class="col-sm-2 control-label" for="normal-field">Audio</label>
                                <div class="col-sm-4">
                                    <input type="file" id="normal-field" class="form-control" name="audio" value='<?php echo set_value(' audio ');?>'>
                                </div>
                            </div>
                            <div class=" form-group videoclass" style="display:none;">
                                <label class="col-sm-2 control-label" for="normal-field">Video</label>
                                <div class="col-sm-4">
                                    <input type="file" id="normal-field" class="form-control" name="video" value='<?php echo set_value(' video ');?>'>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="normal-field">&nbsp;</label>
                                <div class="col-sm-4">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                    <a href="<?php echo site_url("site/viewusergallery?id=".$user); ?>" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                    </form>
                    </div>
            </section>
            </div>
        </div>
    </div>
    <script>
    function changetype() {
        console.log($('#select88').val());
        if($('#select88').val()==0)
        {
            $( ".imageclass" ).show();
            $( ".videoclass" ).hide();
            $( ".audioclass" ).hide();
        }
        else if($('#select88').val()==1)
        {
            $( ".audioclass" ).show();
            $( ".videoclass" ).hide();
            $( ".imageclass" ).hide();
        }
        else if($('#select88').val()==2)
        {
           $( ".videoclass" ).show();
            $( ".audioclass" ).hide();
            $( ".imageclass" ).hide();
        }
        else
        {
            $( ".imageclass" ).hide();
            $( ".audioclass" ).hide();
            $( ".videoclass" ).hide();
        }
    }
        </script>
