<?php
controller-

view-

        
        $data["page2"]="block/userblock";
        $data['user']=$this->input->get('id');
        $data['before']=$this->user_model->beforeedit($this->input->get('id'));

create-
    
 Add this-       $data["page2"]="block/userblock";
        $data['user']=$this->input->get('id');
        $data['before']=$this->user_model->beforeedit($this->input->get('id'));
        $this->load->view("templatewith2",$data);
 =========   
<div class=" form-group" style="display:none;">
                                <label class="col-sm-2 control-label" for="normal-field">User</label>
                                <div class="col-sm-6">
                                    <input type="text" id="normal-field" class="form-control" name="user" value='<?php echo set_value(' user ',$user);?>'>
                                </div>
                            </div>
===========
    edit-
    
        $data["page2"]="block/userblock";
        $data['user']=$this->input->get('id');
        $data['before']=$this->user_model->beforeedit($this->input->get('id'));
    
    delete-
    
    views
    " + resultrow.user + "&userserviceid="+resultrow.id+"
        
        
        
        
        
        
        
        <div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;"><h4>A PHP Error was encountered</h4><p>Severity: Notice</p><p>Message:  Undefined property: stdClass::$order</p><p>Filename: backend/edituserregistration.php</p><p>Line Number: 24</p></div>
            
            
            
            
            
            
            
            
            
            