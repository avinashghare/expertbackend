<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editquestion?id=').$before->id; ?>">Question Details</a></li>
<li><a href="<?php echo site_url('site/viewquestionuser?id=').$before->id; ?>">Question Users</a></li>
</ul>
</div>
</section>